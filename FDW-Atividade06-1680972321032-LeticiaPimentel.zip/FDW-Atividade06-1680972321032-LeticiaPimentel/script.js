let estoque = [
    { marca: "Ferrari", modelo: "F40", ano: 1987, preco: 5000000, cor: "Vermelho" },
    { marca: "Fiat", modelo: "Uno", ano: 2010, preco: 25000, cor: "Branco" }
];

function renderizarTabela(dados) {
    const tbody = document.getElementById('listaVeiculos');
    tbody.innerHTML = '';

    dados.forEach(veiculo => {
        tbody.innerHTML += `<tr>
            <td>${veiculo.marca}</td>
            <td>${veiculo.modelo}</td>
            <td>${veiculo.ano}</td>
            <td>${veiculo.cor}</td>
            <td>R$ ${veiculo.preco.toLocaleString('pt-BR')}</td>
        </tr>`;
    });
}

function adicionarVeiculo() {
    const marca = document.getElementById('marca').value;
    const modelo = document.getElementById('modelo').value;
    const ano = document.getElementById('ano').value;
    const preco = parseFloat(document.getElementById('preco').value);
    const cor = document.getElementById('cor').value;

    if (marca && modelo && !isNaN(preco)) {
        estoque.push({ marca, modelo, ano, preco, cor });
        renderizarTabela(estoque);
        document.querySelectorAll('input').forEach(i => i.value = '');
    }
}

function filtrarPorMarca() {
    const busca = document.getElementById('buscaMarca').value.toLowerCase();
    const filtrados = estoque.filter(v => v.marca.toLowerCase().includes(busca));
    renderizarTabela(filtrados);
}

function aplicarReajuste() {
    const pct = parseFloat(document.getElementById('porcentagemReajuste').value);
    if (!isNaN(pct)) {
        estoque.forEach(v => {
            v.preco += (v.preco * (pct / 100));
        });
        renderizarTabela(estoque);
    }
}

renderizarTabela(estoque);